<script setup>

import Nav from "./Nav.vue";
import Header from "./Header.vue";
import Footer from "./Footer.vue";
import Contact from "./Contact.vue";
import Activity from "./Activity.vue";
import About from "./About.vue";
</script>
<template>
	<Nav/>
	<Header/>
	<Activity/>
	<About/>
	<Contact/>
	<Footer/>
</template>

